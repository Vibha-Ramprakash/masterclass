#!/usr/bin/env python3
"""Find free CC0 sound effects on Openverse (mostly Freesound) and download them.

  python3 openverse_find.py "page flip"            # list the top 8 short CC0 hits
  python3 openverse_find.py "page flip" --get 1 3  # download hits 1 and 3

CC0 only = free for anything, paid work included, no credit needed (credits are logged anyway).
Saves into "brand guidelines/sounds/" if that folder exists here, otherwise "sounds/".
Use --to <folder> to save somewhere else. Every download is logged in CREDITS.md next to it.
Free starter by @vibha.in.progress.
"""
import json, sys, re, urllib.request, urllib.parse, pathlib

UA = {"User-Agent": "free-sfx-finder/1.0"}


def search(q, n=8):
    url = "https://api.openverse.org/v1/audio/?" + urllib.parse.urlencode(
        {"q": q, "license": "cc0", "page_size": 20})
    d = json.load(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30))
    res = [r for r in d.get("results", []) if 0 < (r.get("duration") or 0) <= 8000]  # 8 s max
    res.sort(key=lambda r: r.get("duration") or 0)
    return res[:n]


def out_dir(a):
    if "--to" in a:
        return pathlib.Path(a[a.index("--to") + 1])
    brand = pathlib.Path("brand guidelines") / "sounds"
    return brand if brand.parent.is_dir() else pathlib.Path("sounds")


def main():
    a = sys.argv[1:]
    if not a or a[0].startswith("-"):
        print(__doc__); return
    q = a[0]
    get = []
    if "--get" in a:
        for x in a[a.index("--get") + 1:]:
            if not x.isdigit(): break
            get.append(int(x))
    hits = search(q)
    if not hits:
        print("No short CC0 sounds found. Try a simpler word (e.g. 'click', 'pop', 'paper')."); return
    for i, r in enumerate(hits, 1):
        print(f"{i}. {r['title'][:45]:45} {(r.get('duration') or 0)/1000:5.2f}s  {r.get('foreign_landing_url','')}")
    if not get:
        return
    out = out_dir(a); out.mkdir(parents=True, exist_ok=True)
    for i in get:
        if not 1 <= i <= len(hits):
            print(f"skipped {i}: not in the list"); continue
        r = hits[i - 1]
        ext = (r.get("filetype") or pathlib.Path(urllib.parse.urlparse(r["url"]).path).suffix.strip(".") or "mp3")
        name = re.sub(r"[^a-z0-9]+", "-", f"{q}-{r['title']}".lower()).strip("-")[:60] + f".{ext}"
        dest = out / name
        dest.write_bytes(urllib.request.urlopen(urllib.request.Request(r["url"], headers=UA), timeout=60).read())
        with open(out / "CREDITS.md", "a") as f:
            f.write(f"- `{name}` · {r['title']} by {r.get('creator','?')} · CC0 · {r.get('foreign_landing_url','')}\n")
        print("saved", dest)


if __name__ == "__main__":
    main()

---
name: free-sfx-finder
description: "[FREE STARTER by @vibha.in.progress] Find free CC0 sound effects (Openverse / Freesound, safe for paid work) and place them on the cuts of an edited video. Trigger when someone says 'find a sound effect', 'free sound for…', 'add sound effects', 'sound on every cut', or the edit sounds empty."
---

# Free SFX finder

## 1 · Find a sound
Run `python3 ~/.claude/skills/free-sfx-finder/scripts/openverse_find.py "<plain word>"` from the user's project folder.
- Use simple real-world words: "click", "pop", "paper", "camera shutter", "keyboard", "bell", "swoosh cloth".
- Show the user the list in plain English (name + length). Download only what they pick: add `--get 1 3`.
- It saves into `brand guidelines/sounds/` if that folder exists, else `sounds/`, and logs credits in `CREDITS.md`.
- Only CC0 sounds are listed, so they are free for anything, paid work included.
- Before using a new file, check it with ffmpeg: trim silence at the start, add a 30 ms fade-out so the tail does not click.

## 2 · Place sounds on the cuts (starter rules)
1. List every cut and every on-screen pop-up with its exact time (from the edit's own timeline, not by guessing).
2. Hook / title lands: one soft impact. Every cut: a tiny click or soft pop. Number cards: a bell. Pop-ups: a bubble pop.
3. The sound's loudest moment sits ON the cut frame (shift it earlier by its attack time). Never more than 100 ms late.
4. Keep sound effects well under the voice (start around -20 dB below it). The voice must always win.
5. Do not use the same file twice in a row: alternate 2-3 similar takes.
6. Leave one or two quiet beats so the big moments land.
7. Final mix around -14 LUFS, peaks at or below -1 dB.
8. Tell the user in a short table: time · what happens on screen · which sound. Wait for their OK before rendering the final.

/* Style-pack engine (shared by the Nate v2, Kallaway and Whimsical Yap packs).
   Everything on screen is a pure function of time: call seek(t). No chained tweens. */
const E = {};
E.clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
E.lerp = (a, b, k) => a + (b - a) * k;
E.p = (t, s, d) => E.clamp((t - s) / d);              // 0..1 progress of a move that starts at s and lasts d
E.ease = {
  lin: x => x,
  out: x => 1 - Math.pow(1 - x, 3),                   // fast in, soft landing
  out5: x => 1 - Math.pow(1 - x, 5),
  inout: x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2,
  sine: x => -(Math.cos(Math.PI * x) - 1) / 2,        // the gentle one (yap zooms)
  back: x => { const c = 1.70158; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }
};
E.$ = id => document.getElementById(id);
E.frameNo = t => Math.max(1, Math.min(TAKE.n, Math.floor(t * TAKE.fps + 1e-6) + 1));
E.frameSrc = t => `${TAKE.dir}/frames/${String(E.frameNo(t)).padStart(4, '0')}.jpg`;
// average face position over a shot, so each shot is a locked-off camera (no tracking wobble)
E.faceAvg = (s, e) => {
  const a = Math.max(0, Math.floor(s * TAKE.fps)), b = Math.min(TAKE.n - 1, Math.floor(e * TAKE.fps));
  let x = 0, y = 0, w = 0, n = 0;
  for (let i = a; i <= b; i++) { const r = TAKE.track[i]; x += r[0]; y += r[1]; w += r[2]; n++; }
  return { x: x / n, y: y / n, w: w / n };
};
/* Put the take inside a box so the face lands where you want it.
   box = {w,h} of the window in px · f = faceAvg · fx,fy = where the face centre sits inside the box (0..1)
   faceW = face width as a share of box width · zoom = extra scale on top (for pushes) */
E.placeFace = (img, box, f, o) => {
  const sW = TAKE.w, sH = TAKE.h;
  let sc = (o.faceW * box.w) / (f.w * sW) * (o.zoom || 1);
  sc = Math.max(sc, box.w / sW, box.h / sH);
  let x = o.fx * box.w - f.x * sW * sc, y = o.fy * box.h - f.y * sH * sc;
  x = Math.min(0, Math.max(box.w - sW * sc, x)); y = Math.min(0, Math.max(box.h - sH * sc, y));
  img.style.width = sW * sc + 'px'; img.style.height = sH * sc + 'px';
  img.style.transform = `translate(${x}px,${y}px)`;
};
// face for a shot: steady size + height (shot average), but x follows her slowly so she never drifts out of the window
E.faceShot = (b, t) => {
  if (!b._avg) b._avg = E.faceAvg(b.s, b.e);
  const i = Math.min(TAKE.n - 1, Math.max(0, Math.floor(t * TAKE.fps))), a = Math.max(0, i - 18), z = Math.min(TAKE.n - 1, i + 18);
  let x = 0; for (let k = a; k <= z; k++) x += TAKE.track[k][0];
  return { x: x / (z - a + 1), y: b._avg.y, w: b._avg.w };
};
E.beatAt = (beats, t) => beats.find(b => t >= b.s && t < b.e) || beats[beats.length - 1];
E.wordsIn = (s, e) => WORDS.filter(w => w.s >= s - 1e-3 && w.s < e);
/* caption chunks: [{s,e,text,words:[...]}] of max n words, never crossing a beat edge or a pause > gap */
E.chunks = (beats, n, gap = 0.45) => {
  const out = [];
  for (const b of beats) {
    let cur = null;
    for (const w of E.wordsIn(b.s, b.e)) {
      if (!cur || cur.words.length >= n || w.s - cur.e > gap || /[.!?,]$/.test(cur.words[cur.words.length - 1].w)) { cur = { s: w.s, e: w.e, words: [], beat: b }; out.push(cur); }
      cur.words.push(w); cur.e = w.e;
    }
  }
  out.forEach((c, i) => { const nx = out[i + 1]; c.hold = nx ? Math.min(nx.s, c.e + 0.35) : c.e + 0.5; c.text = c.words.map(w => w.w).join(' '); });
  return out;
};
E.fmt = n => Math.round(n).toLocaleString('en-US');
let _src = '';
async function seek(t) {
  t = E.clamp(t, 0, TAKE.dur - 1 / TAKE.fps);
  const img = E.$('take'), src = E.frameSrc(t);
  if (src !== _src) { _src = src; img.src = src; try { await img.decode(); } catch (e) { } }
  STYLE.draw(t);
  return true;
}
window.seek = seek;
window.addEventListener('load', async () => {
  const render = new URLSearchParams(location.search).has('render');
  const st = E.$('stage');
  if (!render) {   // live preview: fits the window, loops, click to pause, voice plays muted by default
    const fit = () => { const k = Math.min(innerWidth / 1080, innerHeight / 1920); st.style.transform = `scale(${k})`; st.style.transformOrigin = '0 0'; };
    fit(); addEventListener('resize', fit);
    let t0 = performance.now(), paused = false, off = 0;
    st.addEventListener('click', () => { paused = !paused; if (!paused) t0 = performance.now() - off * 1000; });
    const loop = async () => { if (!paused) { off = ((performance.now() - t0) / 1000) % TAKE.dur; await seek(off); } requestAnimationFrame(loop); };
    loop();
  }
  await document.fonts.ready; if (STYLE.init) STYLE.init(); await seek(0); window.READY = true;
});

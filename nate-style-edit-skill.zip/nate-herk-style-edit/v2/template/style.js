/* NATE HERK v2 look. Numbers measured from @nateherkai reels (Jul-Nov 2026), see ../BREAKDOWN.md.
   Layouts: split (media top 45.5%, face below, caption ON the seam) · face (2x punch, caption at chest) · full (media full screen, caption mid).
   Every change of layout is a HARD CUT. The only motion: 4% settle on the punch, slow 6% push on media, things building inside the media. */
const SEAM = 874;                 // 0.455 x 1920
const COL = { white: '#fff', mint: '#2EE6C5', green: '#39FF6A', red: '#FF2D2D' };
const P = {};                     // media panels: P[type](el, m, lt, dur)  lt = seconds since the beat started
const esc = s => String(s).replace(/</g, '&lt;');
P.logo = (el, m, lt) => {         // logo on a dark glow, pops in, then "breaks" at m.breakAt
  const k = E.ease.back(E.p(lt, 0.05, 0.3)), br = m.breakAt != null && lt >= m.breakAt, bt = lt - (m.breakAt || 0);
  const j = br && bt < 0.4 ? Math.sin(bt * 90) * 14 * (1 - bt / 0.4) : 0;
  el.style.background = `radial-gradient(90% 80% at 30% 20%, ${br ? '#6b1414' : (m.glow || '#3a2a6b')} 0%, #101112 62%)`;
  el.innerHTML = `<img src="${m.src}" style="position:absolute;left:50%;top:46%;width:400px;transform:translate(-50%,-50%) translateX(${j}px) scale(${k});filter:${br ? 'saturate(.35) drop-shadow(10px 0 0 rgba(255,45,45,.75)) drop-shadow(-10px 0 0 rgba(46,230,197,.6))' : 'drop-shadow(0 20px 40px rgba(0,0,0,.5))'}">` +
    (br ? `<div style="position:absolute;left:50%;top:46%;transform:translate(-50%,-50%) translate(200px,-180px) scale(${E.ease.back(E.p(bt, 0, .22))});width:0;height:0;border-left:62px solid transparent;border-right:62px solid transparent;border-bottom:108px solid #fff;filter:drop-shadow(0 0 0 #FF2D2D) drop-shadow(0 8px 18px rgba(0,0,0,.5))"><b style="position:absolute;left:-12px;top:30px;font:900 64px Mont;color:#FF2D2D">!</b></div>` : '');
};
P.counter = (el, m, lt, dur) => { // white card: number counts up, bars grow
  const k = E.ease.out(E.p(lt, 0.15, m.countDur || Math.min(2.2, dur - 0.3))), n = m.to * k, up = E.ease.out(E.p(lt, 0, 0.3));
  el.style.background = m.bg || '#ECEEF2';
  let bars = ''; for (let i = 0; i < 9; i++) { const h = (0.12 + 0.88 * Math.pow((i + 1) / 9, 2.2)) * E.ease.out(E.p(lt, 0.2 + i * 0.09, 0.5)); bars += `<i style="display:inline-block;width:52px;margin:0 9px;height:${h * 250}px;border-radius:10px 10px 0 0;background:${i === 8 ? '#18C99B' : '#BFEDE0'};vertical-align:bottom"></i>`; }
  el.innerHTML = `<div class="card" style="left:90px;top:${130 + (1 - up) * 60}px;width:900px;height:640px;opacity:${up}">
    <div style="position:absolute;left:54px;top:44px;font:600 34px Mont;color:#7b828c">${esc(m.label || 'Views')}</div>
    <div style="position:absolute;right:54px;top:40px;font:700 28px Mont;color:#0f9d77;background:#DDF7EF;border-radius:999px;padding:8px 22px">${esc(m.chip || '')}</div>
    <div style="position:absolute;left:50px;top:92px;font:800 132px Mont;letter-spacing:-4px;color:#14171a">${E.fmt(n)}${k >= 1 ? (m.suffix || '') : ''}</div>
    <div style="position:absolute;left:36px;right:36px;bottom:44px;height:250px;white-space:nowrap;text-align:center;border-bottom:3px solid #e6e8ec">${bars}</div></div>`;
};
P.cover = (el, m, lt) => {         // one image as a floating card on a flat colour (full-screen beats)
  const up = E.ease.out(E.p(lt, 0, 0.35));
  el.style.background = m.bg || '#F4F4F2';
  el.innerHTML = `<img src="${m.src}" style="position:absolute;left:50%;top:50%;width:${m.w || 640}px;border-radius:38px;transform:translate(-50%,-50%) translateY(${(1 - up) * 70}px);opacity:${up};box-shadow:0 50px 110px rgba(0,0,0,.35),0 6px 18px rgba(0,0,0,.18)">` +
    (m.chip ? `<div style="position:absolute;left:50%;top:${m.chipY || 1560}px;transform:translateX(-50%) scale(${E.ease.back(E.p(lt, 0.35, 0.3))});font:800 46px Mont;color:#fff;background:#14171a;border-radius:999px;padding:16px 38px;white-space:nowrap">${esc(m.chip)}</div>` : '');
};
P.comments = (el, m, lt) => {      // comment rows slide up one by one
  el.style.background = m.bg || '#101214';
  const step = m.every || 0.32; let h = `<div style="position:absolute;left:70px;top:70px;font:700 36px Mont;color:#8c949e">${esc(m.title || 'Comments')}</div><div style="position:absolute;right:70px;top:60px;font:800 40px Mont;color:#fff;background:#FF2D55;border-radius:999px;padding:8px 26px">${E.fmt(Math.min(m.count || 0, (m.count || 0) * E.ease.out(E.p(lt, 0.1, 1.8))))}${m.count ? '+' : ''}</div>`;
  m.items.forEach((txt, i) => { const k = E.ease.out(E.p(lt, 0.1 + i * step, 0.3)); if (k <= 0) return;
    h += `<div style="position:absolute;left:70px;top:${160 + i * 132 + (1 - k) * 50}px;width:940px;height:112px;border-radius:24px;background:#1b1e22;border:1.5px solid #2a2f35;opacity:${k}">
      <i style="position:absolute;left:22px;top:20px;width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,hsl(${(i * 67) % 360} 80% 62%),hsl(${(i * 67 + 60) % 360} 80% 52%))"></i>
      <i style="position:absolute;left:116px;top:24px;width:${150 + (i * 37) % 90}px;height:16px;border-radius:8px;background:#3a4048"></i>
      <span style="position:absolute;left:116px;top:50px;font:600 38px Mont;color:#f2f4f6;white-space:nowrap">${esc(txt)}</span></div>`; });
  el.innerHTML = h;
};
P.dms = (el, m, lt) => {           // chat bubbles pop in
  el.style.background = m.bg || 'linear-gradient(160deg,#F7F2FF,#EAF3FF)';
  let h = ''; m.items.forEach((txt, i) => { const k = E.ease.back(E.p(lt, 0.08 + i * (m.every || 0.34), 0.28)); if (k <= 0) return;
    h += `<div style="position:absolute;left:80px;top:${110 + i * 178}px;transform-origin:0 100%;transform:scale(${k});max-width:860px;font:600 42px Mont;line-height:1.2;color:#14171a;background:#fff;border-radius:38px 38px 38px 8px;padding:30px 40px;box-shadow:0 14px 34px rgba(60,50,120,.16)">${esc(txt)}</div>`; });
  el.innerHTML = h;
};
P.image = (el, m) => { el.style.background = m.bg || '#111'; el.innerHTML = `<img src="${m.src}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:${m.fit || 'cover'};object-position:50% ${(m.y ?? 0.2) * 100}%">`; };
P.frames = (el, m, lt) => {        // a screen recording, pre-split into jpgs: media/<dir>/0001.jpg at m.fps
  const n = Math.max(1, Math.min(m.n, Math.floor((lt + (m.start || 0)) * (m.fps || 30)) + 1));
  el.style.background = m.bg || '#111'; el.innerHTML = `<img src="${m.dir}/${String(n).padStart(4, '0')}.jpg" style="position:absolute;inset:0;width:100%;height:100%;object-fit:${m.fit || 'cover'};object-position:50% ${(m.y ?? 0) * 100}%">`;
};
const STYLE = {
  init() { },
  draw(t) {
    const b = E.beatAt(PLAN.beats, t), lt = t - b.s, dur = b.e - b.s;
    const mb = E.$('mediaBox'), fb = E.$('faceBox'), img = E.$('take'), cap = E.$('cap'), med = E.$('media');
    let capY, pillDefault = false;
    if (b.layout === 'face') {            // full-face punch: face ~58% of frame width, eyes on the upper third, 4% settle in 0.2s then a 2% drift
      mb.style.display = 'none'; fb.style.display = 'block'; fb.style.top = '0px'; fb.style.width = '1080px'; fb.style.height = '1920px';
      const z = (b.zoom || 1) * (0.96 + 0.04 * E.ease.out(E.p(lt, 0, 0.2)) + 0.02 * (lt / Math.max(dur, 0.1)));
      E.placeFace(img, { w: 1080, h: 1920 }, E.faceShot(b, t), { fx: 0.5, fy: b.fy ?? 0.37, faceW: b.faceW ?? 0.58, zoom: z });
      capY = b.capY ?? 1270;
    } else if (b.layout === 'full') {     // media owns the screen
      fb.style.display = 'none'; mb.style.display = 'block'; mb.style.top = '0px'; mb.style.width = '1080px'; mb.style.height = '1920px';
      capY = b.capY ?? 1090; pillDefault = true;
    } else {                              // split
      mb.style.display = 'block'; mb.style.top = '0px'; mb.style.width = '1080px'; mb.style.height = SEAM + 'px';
      fb.style.display = 'block'; fb.style.top = SEAM + 'px'; fb.style.width = '1080px'; fb.style.height = (1920 - SEAM) + 'px';
      E.placeFace(img, { w: 1080, h: 1920 - SEAM }, E.faceShot(b, t), { fx: 0.5, fy: b.fy ?? 0.44, faceW: b.faceW ?? 0.30, zoom: 1 });
      capY = SEAM;
    }
    if (b.layout !== 'face' && b.media) { med.style.transform = `scale(${1 + 0.06 * (lt / Math.max(dur, 0.1))})`; (P[b.media.type] || P.image)(med, b.media, lt, dur); }
    const c = PLAN.captions.find(c => t >= c.s && t < c.e);
    if (!c) { cap.innerHTML = ''; return; }
    const pop = 0.9 + 0.1 * E.ease.out(E.p(t, c.s, 0.08));          // 2-3 frame pop, never a slide
    const pill = c.pill ?? pillDefault, col = COL[c.c] || c.c || '#fff';
    cap.style.top = capY + (c.l2 ? 30 : 0) + 'px';
    cap.innerHTML = `<div style="transform:scale(${c.l2 ? 1 : pop})"><span class="l1${pill ? ' pill' : ''}" style="color:${c.l2 ? '#fff' : col}">${esc(c.l1)}</span>` +
      (c.l2 ? `<span class="l2" style="color:${col};transform:scale(${pop});display:block">${esc(c.l2)}</span>` : '') + `</div>`;
  }
};

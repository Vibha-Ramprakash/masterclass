// The edit, written by Claude from take/take.js (words + pauses). Times are seconds in the cut take.
window.PLAN = {
  sfx_vol: 0.32,
  beats: [
    { s: 0,     e: 2.06,  layout: 'split', media: { type: 'logo', src: 'media/instagram.png', breakAt: 0.66 } },
    { s: 2.06,  e: 3.28,  layout: 'face' },
    { s: 3.28,  e: 5.65,  layout: 'split', media: { type: 'counter', to: 1000000, suffix: '+', label: 'Views on one reel', chip: 'first 24 hours', countDur: 1.6 } },
    { s: 5.65,  e: 7.2,   layout: 'full',  media: { type: 'cover', src: 'media/reel.jpg', w: 620, chip: '1,000,000+ views', chipY: 1590 }, capY: 300 },
    { s: 7.2,   e: 8.05,  layout: 'face' },
    { s: 8.05,  e: 11.2,  layout: 'split', media: { type: 'comments', every: 0.5, title: 'Comments', count: 10000, items: ['how did you edit this??', 'teach me please', 'which AI is this?', 'need this for my reels', 'EDIT'] } },
    { s: 11.2,  e: 12.64, layout: 'split', media: { type: 'dms', items: ['Can you teach me to edit with AI?', 'How are you doing this??', 'Please share the setup'] } },
    { s: 12.64, e: 15,    layout: 'face' }
  ],
  // l1 = ALL CAPS line · l2 = lowercase serif line that joins under it · c = mint | green | red · pill = dark box (use over busy or light media)
  captions: [
    { s: 0.26,  e: 0.98,  l1: 'I JUST BROKE', c: 'red' },
    { s: 0.98,  e: 2.0,   l1: 'I JUST BROKE', l2: 'instagram', c: 'mint' },
    { s: 2.12,  e: 2.62,  l1: 'THIS ONE REEL' },
    { s: 2.62,  e: 3.28,  l1: 'THIS ONE REEL', l2: 'of mine', c: 'mint' },
    { s: 3.28,  e: 3.6,   l1: 'GOT ME OVER', pill: true },
    { s: 3.6,   e: 4.3,   l1: 'A MILLION VIEWS', c: 'green', pill: true },
    { s: 4.3,   e: 5.6,   l1: 'IN 24 HOURS', pill: true },
    { s: 7.2,   e: 8.05,  l1: 'WITH TENS OF' },
    { s: 8.9,   e: 10.36, l1: 'THOUSANDS OF YOU', c: 'mint' },
    { s: 10.36, e: 11.2,  l1: 'COMMENTING' },
    { s: 11.2,  e: 12.0,  l1: 'AND DMING ME', pill: true },
    { s: 12.0,  e: 12.64, l1: 'TO ASK ME', pill: true },
    { s: 12.64, e: 13.28, l1: 'HOW TO EDIT' },
    { s: 13.28, e: 14.7,  l1: 'HOW TO EDIT', l2: 'with AI', c: 'green' }
  ],
  // one soft sound per visual beat. Never a whoosh.
  sfx: [
    { t: 0.0, name: 'subdrop', vol: 1 }, { t: 0.66, name: 'ping', vol: .7 },
    { t: 2.06, name: 'flick' }, { t: 3.28, name: 'flick' }, { t: 3.4, name: 'ticks', vol: .8 }, { t: 4.9, name: 'chime', vol: .8 },
    { t: 5.65, name: 'flick' }, { t: 7.2, name: 'flick' }, { t: 8.05, name: 'flick' }, { t: 8.3, name: 'ticks', vol: .6 },
    { t: 11.2, name: 'flick' }, { t: 11.3, name: 'ping', vol: .5 }, { t: 12.64, name: 'flick' }, { t: 13.28, name: 'chime', vol: .7 }
  ]
};

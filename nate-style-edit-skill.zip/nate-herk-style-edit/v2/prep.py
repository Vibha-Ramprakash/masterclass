#!/usr/bin/env python3
"""prep.py <video> <out_take_dir> [--start S] [--dur D] [--fps 30]
Turns a talking-head video into what the template needs: frames/, voice.wav, take.js (face track + words).
Needs ffmpeg, opencv-python-headless==4.10.0.84, and mlx-whisper (Mac) or faster-whisper."""
import sys, os, json, glob, subprocess, argparse
ap = argparse.ArgumentParser(); ap.add_argument('video'); ap.add_argument('out'); ap.add_argument('--start', type=float, default=0); ap.add_argument('--dur', type=float, default=None); ap.add_argument('--fps', type=int, default=30); ap.add_argument('--words', default=None)
a = ap.parse_args(); os.makedirs(a.out + '/frames', exist_ok=True)
cut = ['-ss', str(a.start)] + (['-t', str(a.dur)] if a.dur else [])
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + cut + ['-i', a.video, '-vf', f'fps={a.fps},scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920', '-q:v', '3', a.out + '/frames/%04d.jpg'], check=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + cut + ['-i', a.video, '-vn', '-ac', '2', '-ar', '48000', a.out + '/voice.wav'], check=True)
fs = sorted(glob.glob(a.out + '/frames/*.jpg'))
import cv2, numpy as np
cc = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'); raw = []
for i, f in enumerate(fs):
    if i % 3: raw.append(None); continue
    g = cv2.resize(cv2.cvtColor(cv2.imread(f), cv2.COLOR_BGR2GRAY), (540, 960)); r = cc.detectMultiScale(g, 1.1, 6, minSize=(40, 40))
    raw.append([(r0[0] + r0[2] / 2) / 540, (r0[1] + r0[3] / 2) / 960, r0[2] / 540] if len(r) and (r0 := max(r, key=lambda b: b[2] * b[3])) is not None else None)
idx = [i for i, v in enumerate(raw) if v]
if not idx: sys.exit('No face found. Is this a talking-head video?')
arr = np.array([raw[i] for i in idx]); full = np.stack([np.interp(range(len(fs)), idx, arr[:, k]) for k in range(3)], 1)
k = 15; sm = np.stack([np.convolve(np.pad(full[:, j], (k // 2, k // 2), 'edge'), np.ones(k) / k, 'valid') for j in range(3)], 1)
if a.words: words = json.load(open(a.words))
else:
    try:
        import mlx_whisper; r = mlx_whisper.transcribe(a.out + '/voice.wav', path_or_hf_repo='mlx-community/whisper-small-mlx', word_timestamps=True)
        words = [{'w': w['word'].strip(), 's': round(w['start'], 2), 'e': round(w['end'], 2)} for s in r['segments'] for w in s['words']]
    except ImportError:
        from faster_whisper import WhisperModel; seg, _ = WhisperModel('small').transcribe(a.out + '/voice.wav', word_timestamps=True)
        words = [{'w': w.word.strip(), 's': round(w.start, 2), 'e': round(w.end, 2)} for s in seg for w in s.words]
take = {'dir': 'take', 'fps': a.fps, 'n': len(fs), 'dur': len(fs) / a.fps, 'w': 1080, 'h': 1920, 'track': [[round(float(v), 4) for v in r] for r in sm]}
open(a.out + '/take.js', 'w').write('window.TAKE=' + json.dumps(take) + ';\nwindow.WORDS=' + json.dumps(words) + ';\n')
print(f'{len(fs)} frames, {len(words)} words ->', a.out)

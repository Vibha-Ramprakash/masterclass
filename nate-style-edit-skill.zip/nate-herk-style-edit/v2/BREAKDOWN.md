# Nate Herk v2 · what we measured (12 Nov 2026)

Source: @nateherkai. Studied frame by frame: DbLuwUVlE9Z (24 Jul, 1.02M views), DfkTLJ-E7_q (10 Nov), DfnFw5MiSo6 (11 Nov). Cross-checked on DfaNcY1FdlE, Dfm3zUdHNBs, DdhR21VBfQH, DeaxjcMBKBy. All numbers are for a 1080×1920 frame. Inspired by, not affiliated.

## The shift (July → November)
| | July (design layout in every beat) | November (face punches + design) |
|---|---|---|
| Layout | split almost the whole reel, one face punch | split + **2× full-face punches** several times a reel + full-screen stock b-roll |
| Captions | Sentence case, white on a grey rounded box, mint or red key phrase | **ALL CAPS** Montserrat ExtraBold with a dark glow, key phrase as a **lowercase serif line underneath** in mint/green |
| Extras | "#1 / #2" mint tags on list items | neon sign behind him, red tint on "problem" b-roll, comment-pill CTA with a cursor |
| Pace | 17 cuts in 26.6 s (one screen per 1.6 s) | 20 in 43 s and 24 in 52 s (one per 2.1-2.2 s); 17 in 31 s and 20 in 34 s on shorter ones |

## Layout numbers
- **Split:** seam at y = 874 (45.5%). Media box 1080×874 on top. Face box below: face centre at 44% of the box height, face width 30% of frame width.
- **Face punch:** face width 58-62% of the frame (about 2× the split size), eyes on the upper third (face centre y ≈ 37%), caption at y ≈ 1270 (chest). Never on the face.
- **Full media:** the screenshot floats as a rounded card (radius 26-38, soft shadow) on ONE flat colour (white, cream, near-black). Caption centred over it in a pill.

## Captions
- Line 1: Montserrat 800, 66 px, ALL CAPS, 2-3 words. White. Shadow: black glow 14 px + 5 px.
- Line 2 (only on the key phrase): DM Serif Display, 74 px, lowercase, mint `#2EE6C5` or green `#39FF6A`, tucked 2 px under line 1. Line 1 stays on screen while line 2 arrives.
- Whole-line colour: green for wins ("COMPLETELY FREE"), red `#FF2D2D` for problems ("SECURITY ISSUES"), mint for names and numbers.
- Pill: `rgba(52,56,56,.88)`, radius 16, 2 px light border. Use it when the caption sits on light or busy media.
- Position: on the seam in a split, chest in a face punch, middle in full media. It holds that spot for the whole beat.
- Animation: appears on the first syllable with a 2-3 frame pop (90% → 100%). No slide, no typewriter, no bounce.

## Zooms, cuts, motion
- Every layout change is a **hard cut** (0 frames), on a word start.
- Face punch: lands 4% wide and settles in 0.2 s, then drifts in 2% until the next cut.
- Media: slow push, +6% over the beat. Inside the media something always builds: number counts up, rows arrive every 0.3-0.5 s, an orange highlight box draws, a grid fills with red cells, a prompt types.
- Face punch goes on: the hook payoff ("and it's completely free"), "I can literally just say…", the turn before the CTA. 1-2.5 s each.

## B-roll and graphics
Real product pages and dashboards first, then rebuilt UI cards (clean, white or dark), then AI stock b-roll full screen for "you at your desk" lines (blurred copy fills top and bottom, red tint on problems). Logos pop in on a soft glow. A red warning triangle marks the pain line.

## Grade and sound
Bright, slightly cool, soft contrast; skin left natural. Sound: dry voice, a soft click on cuts, a tick run under counters, a chime on the win line, low hit on the hook. No music bed on most, no whooshes. Mix at −14 LUFS.

## Timing to speech
One screen per clause. The media changes on the noun it shows ("Omnisend" → logo, "20,000 stars" → the star count zooms). The serif line lands exactly on the key phrase. Silence longer than 0.5 s is covered with a full-media beat.

Reference frame sheets (not for sharing): `VIDEO-EDITING-BRAIN/03_LIBRARIES/style-refs/2026-11-12_creator-packs/nate-herk/`.

#!/usr/bin/env node
// render.mjs <template-dir> <out.mp4>   Screenshots the template frame by frame and mixes voice + SFX at -14 LUFS.
// Needs: node, ffmpeg, Google Chrome, and puppeteer-core (npm i puppeteer-core in this folder, once).
import { createRequire } from 'module'; import { spawn, execFileSync } from 'child_process'; import fs from 'fs'; import path from 'path'; import os from 'os';
const [, , tdir, out] = process.argv; if (!tdir || !out) { console.error('usage: render.mjs <template-dir> <out.mp4>'); process.exit(1); }
const here = path.dirname(new URL(import.meta.url).pathname);
let pup; for (const base of [here, path.join(os.homedir(), '.cache/vibha-pup'), process.cwd()]) { try { pup = createRequire(path.join(base, 'x.js'))('puppeteer-core'); break; } catch (e) { } }
if (!pup) { console.error('puppeteer-core missing: run  npm i puppeteer-core  in ' + here); process.exit(1); }
const chrome = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe', '/usr/bin/google-chrome'].find(p => fs.existsSync(p));
const T = path.resolve(tdir);
const b = await pup.launch({ executablePath: chrome, headless: 'new', args: ['--allow-file-access-from-files', '--hide-scrollbars', '--force-device-scale-factor=1', '--autoplay-policy=no-user-gesture-required'] });
const pg = await b.newPage(); await pg.setViewport({ width: 1080, height: 1920, deviceScaleFactor: 1 });
pg.on('pageerror', e => { console.error('PAGE ERROR', e.message); process.exit(1); });
await pg.goto('file://' + T + '/index.html?render=1'); await pg.waitForFunction('window.READY===true', { timeout: 60000 });
const info = await pg.evaluate(() => ({ fps: TAKE.fps, n: TAKE.n, sfx: (window.PLAN && PLAN.sfx) || [], sfxVol: (window.PLAN && PLAN.sfx_vol) || 0.5 }));
const tmp = out.replace(/\.mp4$/, '') + '.silent.mp4';
const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(info.fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', tmp], { stdio: ['pipe', 'inherit', 'inherit'] });
for (let i = 0; i < info.n; i++) {
  await pg.evaluate(t => window.seek(t), (i + 0.01) / info.fps);
  const buf = await pg.screenshot({ type: 'jpeg', quality: 95 });
  if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
  if (i % 60 === 0) process.stdout.write(`\r${i}/${info.n}`);
}
ff.stdin.end(); await new Promise(r => ff.on('close', r)); await b.close();
// audio: voice + one sound per visual beat, ducked under the voice, then -14 LUFS
const ins = ['-i', tmp, '-i', path.join(T, 'take/voice.wav')]; const fc = []; const mix = ['[1:a]volume=1.0[v0]']; let k = 2; const labs = ['[v0]'];
for (const s of info.sfx) { const f = path.join(T, 'sfx', s.name + '.wav'); if (!fs.existsSync(f)) continue; ins.push('-i', f); mix.push(`[${k}:a]volume=${(s.vol ?? 1) * info.sfxVol},adelay=${Math.round(s.t * 1000)}:all=1[s${k}]`); labs.push(`[s${k}]`); k++; }
fc.push(mix.join(';') + ';' + labs.join('') + `amix=inputs=${labs.length}:normalize=0:duration=first,loudnorm=I=-14:TP=-1.5:LRA=11[a]`);
execFileSync('ffmpeg', ['-v', 'error', '-y', ...ins, '-filter_complex', fc.join(';'), '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out]);
fs.unlinkSync(tmp); console.log('\nrendered', out);

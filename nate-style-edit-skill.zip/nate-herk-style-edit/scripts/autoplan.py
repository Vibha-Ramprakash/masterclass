# Draft plan.json straight from the transcript, so "edit my video" works even with NO screen recordings.
# Hook beat (face punch-in + cover title) -> then a new visual every ~2.5 s, rotating
# face punch-ins and generated "card" beats (number + key words on top, face below).
# List words ("one", "two", "number three", "first"...) become numbered cards automatically.
# If the free effects pack is installed (~/.claude/skills/effects), it also drafts 1-2 effect beats.
# Claude should then READ the plan and improve every card title + the cover title before rendering.
# Usage: python3 autoplan.py words_cut.json plan.json [--talk take_cut.mp4] [--title "Cover title"] [--no-effects]
import json, os, re, argparse
ap = argparse.ArgumentParser(); ap.add_argument('words'); ap.add_argument('out')
ap.add_argument('--talk', default='take_cut.mp4'); ap.add_argument('--title', default='')
ap.add_argument('--no-effects', action='store_true'); ap.add_argument('--beat', type=float, default=2.5)
a = ap.parse_args()
W = json.load(open(a.words))
if not W: raise SystemExit('No words in transcript')
clean = lambda s: re.sub(r"[^\w'#%$]", '', s.lower())
STOP = set("""a an the and or but so to of in on for with at by from is are was were be been am i you we they he she it this that these those
my your our their me us them do does did have has had just really actually like kind sort very what which who how when where why
if then than there here not no yes can will would should could gonna wanna get got go going about into out up down over one two three
four five six seven eight nine ten first second third next number also all some any more most because it's i'm you're don't that's thing things""".split())
NUM = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
       'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5}

# 1. sentence-ish chunks -> beats of ~2.5 s, cut on word ends
def sentence_end(w): return w['word'].rstrip().endswith(('.', '?', '!'))
beats, cur = [], [W[0]]
hook_done = False
for prev, w in zip(W, W[1:]):
    d = prev['end'] - cur[0]['start']
    limit = (1.8, 3.0) if not hook_done else (a.beat * 0.85, a.beat * 1.5)
    if (d >= limit[0] and (sentence_end(prev) or w['start'] - prev['end'] > 0.15)) or d >= limit[1]:
        beats.append(cur); cur = []; hook_done = True
    cur.append(w)
beats.append(cur)
if len(beats) > 1 and beats[-1][-1]['end'] - beats[-1][0]['start'] < 1.2:  # merge a tiny tail
    tail = beats.pop(); beats[-1] += tail  # (beats[-2] += beats.pop() overwrites the wrong beat)

def keywords(ws, n=2):
    ks = [w['word'].strip(' ,.?!').upper() for w in ws if clean(w['word']) not in STOP and len(clean(w['word'])) > 2]
    return ' '.join(sorted(ks, key=len, reverse=True)[:n]) or ws[0]['word'].strip(' ,.?!').upper()

def list_item(ws):
    for i, w in enumerate(ws):
        k = clean(w['word'])
        prev = clean(ws[i - 1]['word']) if i else ''
        if w['word'].rstrip().endswith(('.', '?', '!', ',')) or prev in ('this', 'that', 'the', 'no', 'any', 'every', 'which'):
            continue  # "including this one." / "the first" is not a list item
        if k in NUM and (k not in ('one', 'first', 'second') or i <= 2 or prev == 'number'):
            rest = [x for x in ws[i + 1:] if clean(x['word']) not in ('is', 'number', 'the', 'a')]
            return NUM[k], keywords(rest or ws, 3)
    return None

# 2. layouts: hook = face + title, list items = numbered cards, else rotate face / card / face
plan_beats, zoom_flip, since_card = [], False, 0
for n, ws in enumerate(beats):
    b = {'start': round(ws[0]['start'], 2) if n else 0, 'end': round(ws[-1]['end'], 2)}
    item = list_item(ws) if n else None
    if n == 0:
        title = a.title or ' '.join(w['word'] for w in ws[:7]).strip(' ,.')
        b.update(layout='face', zoom=1.15, sfx='subdrop', title=title)
    elif item:
        b.update(layout='card', num=f'{item[0]:02d}', title=item[1], sfx=['flick', 'chime']); since_card = 0
    elif n == len(beats) - 1 or since_card < 2:
        zoom_flip = not zoom_flip; b.update(layout='face', zoom=1.12 if zoom_flip else 1.0); since_card += 1
    else:
        b.update(layout='card', title=keywords(ws), sfx=['flick', 'ticks']); since_card = 0
    plan_beats.append(b)
for x, y in zip(plan_beats, plan_beats[1:]): x['end'] = y['start']  # beats touch end-to-start

plan = {'talk': a.talk, 'words': os.path.basename(a.words), 'out': 'final.mp4', 'face_y': 0.3,
        'highlight': [], 'music': None, 'sfx_vol': 0.3, 'resolution': '1080', 'beats': plan_beats}

# 3. optional wow beats from the free effects pack (github.com/Vibha-Ramprakash/claude-video-effects)
FX = os.path.expanduser('~/.claude/skills/effects')
if not a.no_effects and os.path.isdir(FX):
    faces = [b for b in plan_beats[1:] if b['layout'] == 'face']
    h = plan_beats[0]  # hook: their own video frames pile up behind their head ("everyone is talking about...")
    fx = [{'fx': 'noise', 'start': 0.15, 'end': h['end']}]
    if faces:
        f = faces[0]; ws = [w for w in W if f['start'] <= w['start'] < f['end']]
        fx.append({'fx': 'backdrop-word', 'start': f['start'], 'end': f['end'], 'text': keywords(ws, 1)})
    if len(faces) > 2:
        f = faces[len(faces) // 2]; fx.append({'fx': 'lean-in', 'start': f['start'], 'end': min(f['end'], f['start'] + 1.6)})
    plan['effects'] = fx
json.dump(plan, open(a.out, 'w'), indent=1)
print(f"{len(plan_beats)} beats ({sum(b['layout']=='card' for b in plan_beats)} cards)"
      + (f", {len(plan.get('effects', []))} effects" if plan.get('effects') else ', no effects pack found') + f' -> {a.out}')

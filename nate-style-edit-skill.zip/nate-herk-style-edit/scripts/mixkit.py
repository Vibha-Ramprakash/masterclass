# Grab free sound effects from Mixkit (mixkit.co, free for commercial use, no attribution needed) into ./sfx/
# Files are saved under the SAME names render.py already uses, so the next render picks them up automatically
# (a file in ./sfx/ beats the built-in synthesized sound of the same name). No whooshes on purpose.
# Usage: python3 mixkit.py [project_dir]                -> downloads the default kit
#        python3 mixkit.py [project_dir] --swap ping=2357 -> swap one sound for another Mixkit id
#        python3 mixkit.py --browse pop                  -> list sound ids + names in a Mixkit category
import sys, os, re, html, urllib.request
UA = {'User-Agent': 'Mozilla/5.0'}
KIT = {'subdrop': 788,   # hook hit: Big cinematic impact
       'flick': 1109,    # every cut: Select click
       'chime': 938,     # numbered cards: Uplifting bells notification
       'ping': 2357,     # pop-ups: Bubble pop up alert
       'ticks': 2364}    # keyword cards: Hard pop click
def get(url): return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20).read()
a = sys.argv[1:]
if a[:1] == ['--browse']:
    s = get(f'https://mixkit.co/free-sound-effects/{a[1]}/').decode('utf8', 'ignore')
    names = re.findall(r'item-grid-card__title[^>]*>\s*([^<]+?)\s*<', s)
    ids = list(dict.fromkeys(re.findall(r'active_storage/sfx/(\d+)/\1-preview\.mp3', s)))
    for i, n in zip(ids, names): print(i, html.unescape(n))
    sys.exit()
proj = a[0] if a and not a[0].startswith('--') else '.'
for x in a:
    if '=' in x: k, v = x.split('='); KIT[k] = int(v)
out = os.path.join(proj, 'sfx'); os.makedirs(out, exist_ok=True)
for name, i in KIT.items():
    f = os.path.join(out, f'{name}.mp3'); open(f, 'wb').write(get(f'https://assets.mixkit.co/active_storage/sfx/{i}/{i}-preview.mp3'))
    # keep it short and tidy: max 1.6 s with a soft tail, so a long sound never runs under the next line
    t = f[:-4] + '_t.mp3'
    if os.system(f'ffmpeg -v error -y -i "{f}" -af "atrim=0:1.6,afade=t=out:st=1.2:d=0.4" "{t}"') == 0: os.replace(t, f)
    print(f'{name}.mp3  <- mixkit #{i}')
print('Saved to', out, '- render.py will use these instead of the built-in sounds.')

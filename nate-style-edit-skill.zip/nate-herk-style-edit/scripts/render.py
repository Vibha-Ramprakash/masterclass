# Split-screen creator edit from a plan.json (see SKILL.md for the schema).
# Layouts: face (talking head, punch-in), split (media top / face bottom, caption on the seam),
# card (generated number + title card on top / face bottom: works with NO screen recordings),
# full (media full screen + face circle top-right). Cover title on the hook, caption track, SFX, loudness,
# optional effects from the free pack (github.com/Vibha-Ramprakash/claude-video-effects), 2 cover stills.
# Usage: python3 render.py plan.json
import json, sys, os, subprocess, urllib.request, re
from PIL import ImageFilter, Image, ImageDraw, ImageFont
SK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W, H, FPS = 1080, 1920, 30
plan = json.load(open(sys.argv[1])); base = os.path.dirname(os.path.abspath(sys.argv[1]))
P = lambda p: p if os.path.isabs(p) else os.path.join(base, p)
work = P('_work'); os.makedirs(work, exist_ok=True)
run = lambda c: subprocess.run(c, check=True)
dur = lambda f: float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]))
IMG = ('.png', '.jpg', '.jpeg', '.webp')

talk = P(plan['talk']); fy = plan.get('face_y', 0.3)

# 0. effects pre-pass: the free 51-effects pack runs on the talking head first, captions + layouts go on top
if plan.get('effects'):
    FX = os.path.expanduser(plan.get('effects_dir', '~/.claude/skills/effects'))
    py = next((x for x in (os.path.join(FX, '.venv', 'bin', 'python'), os.path.join(FX, '.venv', 'Scripts', 'python.exe')) if os.path.exists(x)), None)
    if py:
        fxp = os.path.join(work, 'fx_plan.json'); json.dump({'effects': plan['effects']}, open(fxp, 'w'))
        fxo = os.path.join(work, 'talk_fx.mp4'); print('effects pass:', ', '.join(e['fx'] for e in plan['effects']))
        run([py, os.path.join(FX, 'scripts', 'fx.py'), '--plan', fxp, talk, fxo]); talk = fxo
    else:
        print('Effects pack not set up, skipping effects. Install: github.com/Vibha-Ramprakash/claude-video-effects')
D = dur(talk)
words = json.load(open(P(plan['words'])))
beats = sorted(plan['beats'], key=lambda b: b['start'])
beats[0]['start'] = 0; beats[-1]['end'] = D
for a, b in zip(beats, beats[1:]):
    if abs(a['end'] - b['start']) > 0.05: sys.exit(f"Gap/overlap between beats at {a['end']} and {b['start']}")
    a['end'] = b['start']

FONT = os.path.join(SK, 'assets', 'Montserrat.ttf')
if not os.path.exists(FONT):
    urllib.request.urlretrieve('https://github.com/google/fonts/raw/main/ofl/montserrat/Montserrat%5Bwght%5D.ttf', FONT)
CIRC = os.path.join(work, 'circle.png'); C = 400; RING = os.path.join(work, 'ring.png')
m = Image.new('L', (C, C), 0); ImageDraw.Draw(m).ellipse([0, 0, C - 1, C - 1], fill=255); m.save(CIRC)
r = Image.new('RGBA', (C + 24, C + 24), (0, 0, 0, 0)); rd = ImageDraw.Draw(r)
rd.ellipse([0, 4, C + 23, C + 23], fill=(0, 0, 0, 90)); rd.ellipse([6, 6, C + 17, C + 17], fill=(255, 255, 255, 255)); r.save(RING)
ACC = plan.get('highlight_color', '#3CE07A')
def font(sz, wt='ExtraBold'):
    f = ImageFont.truetype(FONT, sz)
    try: f.set_variation_by_name(wt)
    except Exception: pass
    return f
def wrap(d, txt, f, maxw):
    lines, cur = [], ''
    for w in txt.split():
        t = (cur + ' ' + w).strip()
        if cur and d.textlength(t, font=f) > maxw: lines.append(cur); cur = w
        else: cur = t
    return lines + [cur]
def make_card(b, n):
    # dark card, soft accent glow, big number, 1-2 line title. Fills the top half (W x H/2).
    w, h = W, H // 2; im = Image.new('RGB', (w, h), '#0D0E12')
    import numpy as np
    yy, xx = np.mgrid[0:h, 0:w]; g = np.exp(-(((xx - w * 0.2) / 520) ** 2 + ((yy - h * 0.15) / 420) ** 2))
    ac = np.array(Image.new('RGB', (1, 1), ACC).getpixel((0, 0)), float)
    arr = np.asarray(im, float) + g[..., None] * ac * 0.28
    im = Image.fromarray(arr.clip(0, 255).astype('uint8')); d = ImageDraw.Draw(im)
    for gx in range(0, w, 60): d.line([(gx, 0), (gx, h)], fill='#15171C')
    for gy in range(0, h, 60): d.line([(0, gy), (w, gy)], fill='#15171C')
    title = b.get('title', '').upper(); num = b.get('num'); y = 300 if num else 360
    if num:
        nf = font(150); d.text((90, 150), str(num), font=nf, fill=ACC, anchor='lm')
        d.rounded_rectangle([90, 228, 210, 236], 4, fill=ACC)
    sz = 120
    while sz > 56:
        tf = font(sz); lines = wrap(d, title, tf, w - 180)
        if len(lines) <= 2 and all(d.textlength(l, font=tf) <= w - 180 for l in lines): break
        sz -= 8
    for i, l in enumerate(lines[:3]): d.text((90, y + i * sz * 1.05), l, font=tf, fill='white', anchor='lt')
    if b.get('sub'): d.text((92, y + len(lines) * sz * 1.05 + 30), b['sub'], font=font(44, 'SemiBold'), fill='#9AA0AA', anchor='lt')
    fn = os.path.join(work, f'card{n:03d}.png'); im.save(fn); return fn
def make_title(txt):
    # cover title: black text on a white rounded box, top third, highlight words in the accent colour
    im = Image.new('RGBA', (W, 640), (0, 0, 0, 0)); d = ImageDraw.Draw(im); sz = 84
    while sz > 50:
        f = font(sz); lines = wrap(d, txt.upper(), f, W - 220)
        if len(lines) <= 3: break
        sz -= 6
    lh = int(sz * 1.18); bh = lh * len(lines) + 70; bw = max(d.textlength(l, font=f) for l in lines) + 90
    x0 = (W - bw) / 2; d.rounded_rectangle([x0 + 8, 18, x0 + bw + 8, bh + 18], 34, fill=(0, 0, 0, 110))
    d.rounded_rectangle([x0, 10, x0 + bw, bh + 10], 34, fill='white')
    HLs = {re.sub(r'[^\w#%$]', '', h.lower()) for h in plan.get('highlight', [])}
    for i, l in enumerate(lines):
        toks = l.split(); sp = d.textlength(' ', font=f); x = (W - d.textlength(l, font=f)) / 2
        for t in toks:
            k = re.sub(r'[^\w#%$]', '', t.lower()); hl = k in HLs or bool(re.search(r'\d', k))
            d.text((x, 45 + i * lh + lh / 2), t, font=f, fill='#12A150' if hl else '#111111', anchor='lm'); x += d.textlength(t, font=f) + sp
    fn = os.path.join(work, 'title.png'); im.save(fn); return fn

def cover(i, w, h, y=0.5, z=1.0, o='x'):
    return f"[{i}]fps={FPS},scale={int(w*z)}:{int(h*z)}:force_original_aspect_ratio=increase,crop={w}:{h}:(iw-{w})/2:(ih-{h})*{y},setsar=1[{o}]"
def fit(i, w, h, o='x', bg='0x0E0E10'):
    return f"[{i}]fps={FPS},scale={w-90}:{h-90}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color={bg},setsar=1[{o}]"

# 1. one clip per beat
segs = []
for n, b in enumerate(beats):
    d = b['end'] - b['start']; L = b.get('layout', 'face'); seg = os.path.join(work, f'seg{n:03d}.mp4')
    ins = ['-ss', f"{b['start']:.3f}", '-t', f'{d:.3f}', '-i', talk]
    if L in ('split', 'full'):
        med = P(b['media'])
        ins += (['-loop', '1', '-t', f'{d:.3f}', '-i', med] if med.lower().endswith(IMG) else ['-stream_loop', '-1', '-i', med])
    ms = b.get('media_start', 0); trim = f"trim=start={ms}:duration={d:.3f},setpts=PTS-STARTPTS,"
    fitting = b.get('fit', b.get('media', '').lower().endswith(IMG))
    if L == 'face':
        zoom = b.get('zoom', 1.12 if n % 2 else 1.0)
        g = cover('0:v', W, H, b.get('face_y', fy), zoom, 'v')
        if b.get('title'):
            ins += ['-loop', '1', '-t', f'{d:.3f}', '-i', make_title(b['title'])]
            g = g.replace('[v]', '[v0]') + f";[1:v]format=rgba,fade=in:st=0:d=0.12:alpha=1[tt];[v0][tt]overlay=0:{b.get('title_y', 250)}[v]"
    elif L == 'card':
        ins += ['-loop', '1', '-t', f'{d:.3f}', '-i', make_card(b, n)]
        g = (f"[1:v]fps={FPS},scale=w='{W}*(1+0.05*t/{d:.3f})':h=-2:eval=frame,crop={W}:{H//2},setsar=1[top];"
             f"{cover('0:v', W, H // 2, b.get('face_y', fy + 0.06), b.get('zoom', 1.22), 'bot')};[top][bot]vstack[v]")
    elif L == 'split':
        top = fit('m', W, H // 2, o='top') if fitting else cover('m', W, H // 2, b.get('media_y', 0.5), o='top')
        g = f"[1:v]{trim}null[m];{top};{cover('0:v', W, H // 2, b.get('face_y', fy), b.get('zoom', 1.0), 'bot')};[top][bot]vstack[v]"
    elif L == 'full':
        bg = fit('m', W, H, o='bg') if fitting else cover('m', W, H, b.get('media_y', 0.5), o='bg')
        g = f"[1:v]{trim}null[m];{bg}"
        if b.get('face_circle', True):
            ins += ['-loop', '1', '-i', CIRC]
            ins += ['-loop', '1', '-i', RING]
            g += (f";[0:v]fps={FPS},crop=iw*0.62:iw*0.62:(iw-ow)/2:(ih-oh)*{b.get('face_y', fy)}*0.75,scale={C}:{C},setsar=1[f0]"
                  f";[f0]format=rgba[f1];[2:v]format=gray[mk];[f1][mk]alphamerge[fc];[bg][3:v]overlay={W-C-60}:{218}[bg2];[bg2][fc]overlay={W-C-48}:230[v]")
        else: g += ";[bg]null[v]"
    else: sys.exit(f'Unknown layout {L}')
    run(['ffmpeg', '-v', 'error', '-y', *ins, '-filter_complex', g + ';[v]format=yuv420p[o]', '-map', '[o]', '-t', f'{d:.3f}',
         '-r', str(FPS), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '16', '-an', seg])
    segs.append(seg); print(f'beat {n+1}/{len(beats)} {L}')
open(os.path.join(work, 'segs.txt'), 'w').write(''.join(f"file '{s}'\n" for s in segs))
video = os.path.join(work, 'video.mp4')
run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', os.path.join(work, 'segs.txt'), '-c', 'copy', video])

# 2. caption track: 1-3 words as spoken (not caps), white bold with a soft shadow,
#    key words (highlight list, numbers) swap to a bigger pale-yellow serif italic. Small pop-in.
HL = {re.sub(r'[^\w#%$]', '', h.lower()) for h in plan.get('highlight', [])}
GREEN, MAXW = plan.get('caption_accent', '#FFE9A8'), plan.get('max_words', 3)
SERIF = os.path.join(SK, 'assets', 'Newsreader-Italic.ttf')
chunks, cur = [], []
for w in words:
    if cur and (len(cur) == MAXW or w['start'] - cur[-1]['end'] > 0.3 or len(' '.join(x['word'] for x in cur + [w])) > 18):
        chunks.append(cur); cur = []
    cur.append(w)
if cur: chunks.append(cur)
def ypos(t):
    L = next((b for b in beats if b['start'] <= t < b['end']), beats[-1]).get('layout', 'face')
    return {'split': H // 2, 'card': H // 2, 'face': 1060, 'full': 1120}[L]
def capfonts(size):
    f = ImageFont.truetype(FONT, size); f.set_variation_by_name('Bold')
    g = ImageFont.truetype(SERIF, int(size * 1.35))
    try: g.set_variation_by_name('Medium Italic')
    except Exception: pass
    return f, g
def cap(ws, y, s):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    size = 70
    while True:
        f, g = capfonts(int(size * s))
        toks = [x['word'].strip() for x in ws]; sp = d.textlength(' ', font=f)
        hls = [re.sub(r'[^\w#%$]', '', t.lower()) in HL or bool(re.search(r'\d', t)) for t in toks]
        tw = sum(d.textlength(t, font=g if h else f) for t, h in zip(toks, hls)) + sp * (len(toks) - 1)
        if tw < W - 160 or size < 40: break
        size -= 6
    x = (W - tw) / 2; sh = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ds = ImageDraw.Draw(sh)
    for t, h in zip(toks, hls):
        ft = g if h else f
        ds.text((x, y + 4), t, font=ft, fill=(0, 0, 0, 210), anchor="lm")
        d.text((x, y), t, font=ft, fill=GREEN if h else 'white', anchor='lm')
        x += d.textlength(t, font=ft) + sp
    sh = sh.filter(ImageFilter.GaussianBlur(8)); sh.alpha_composite(im)
    return sh
blank = os.path.join(work, 'cap_blank.png'); Image.new('RGBA', (W, H), (0, 0, 0, 0)).save(blank)
lst, t = [], 0.0
for k, c in enumerate(chunks):
    s = c[0]['start']; nxt = chunks[k + 1][0]['start'] if k + 1 < len(chunks) else D
    e = nxt if nxt - c[-1]['end'] < 0.4 else c[-1]['end'] + 0.1
    if s > t: lst.append((blank, s - t))
    y = ypos(s)
    for j, sc in enumerate((0.86, 0.95, 1.0)):
        fn = os.path.join(work, f'cap{k:04d}_{j}.png'); cap(c, y, sc).save(fn)
        lst.append((fn, 1 / FPS if j < 2 else max(1 / FPS, e - s - 2 / FPS)))
    t = e
lst.append((blank, max(0.1, D - t)))
open(os.path.join(work, 'caps.txt'), 'w').write(''.join(f"file '{f}'\nduration {d:.4f}\n" for f, d in lst) + f"file '{blank}'\n")
caps = os.path.join(work, 'caps.mov')
run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', os.path.join(work, 'caps.txt'), '-vf', f'fps={FPS},format=argb', '-c:v', 'qtrle', caps])

# 3. sound: voice + SFX (+ optional music), master to -14 LUFS
SFXD = os.path.join(SK, 'assets', 'sfx'); ains = ['-i', talk]; parts = ['[2:a]atrim=0:%f,asetpts=PTS-STARTPTS[a0]' % D]; labs = ['[a0]']
cues = []
for n, b in enumerate(beats):
    sf = b.get('sfx', (['flick', 'chime'] if b.get('num') else 'flick') if n else 'subdrop')
    for s in ([sf] if isinstance(sf, str) else (sf or [])):
        if s and s != 'none': cues.append((s, b['start'] - (0.25 if s == 'whoosh' else 0)))
for i, (s, at) in enumerate(cues):
    own = [P(s)] if '.' in s else [P(os.path.join('sfx', f'{s}.{e}')) for e in ('mp3', 'wav')]  # Mixkit/own sounds win
    ains += ['-i', next((x for x in own if os.path.exists(x)), os.path.join(SFXD, f'{s}.wav'))]; ms = max(0, int(at * 1000))
    parts.append(f'[{i+3}:a]adelay={ms}|{ms},volume={plan.get("sfx_vol", 0.32)}[s{i}]'); labs.append(f'[s{i}]')
if plan.get('music'):
    k = len(cues) + 3; ains += ['-stream_loop', '-1', '-i', P(plan['music'])]
    parts.append(f'[{k}:a]atrim=0:{D},afade=t=out:st={D-1.5}:d=1.5,volume={plan.get("music_vol", 0.08)}[mu]'); labs.append('[mu]')
parts.append(f"{''.join(labs)}amix=inputs={len(labs)}:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[a]")
parts.insert(0, '[0:v][1:v]overlay=0:0' + (f',scale=2160:3840:flags=lanczos' if plan.get('resolution') == '4k' else '') + ',format=yuv420p[v]')
out = P(plan.get('out', 'final.mp4'))
run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-i', caps, *ains, '-filter_complex', ';'.join(parts), '-map', '[v]', '-map', '[a]',
     '-t', f'{D:.3f}', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-g', '30', '-c:a', 'aac', '-b:a', '256k', '-ar', '48000',
     '-movflags', '+faststart', out])

# 4. contact sheet (one frame per beat) for the check pass
sheet = os.path.join(base, 'sheet.jpg'); tiles = []
for n, b in enumerate(beats[:24]):
    fn = os.path.join(work, f'chk{n:02d}.jpg')
    run(['ffmpeg', '-v', 'error', '-y', '-ss', f"{(b['start']+b['end'])/2:.2f}", '-i', out, '-frames:v', '1', '-vf', 'scale=270:480', fn]); tiles.append(fn)
cols = min(6, len(tiles)); rows = -(-len(tiles) // cols); S = Image.new('RGB', (270 * cols, 480 * rows), 'black')
for n, fn in enumerate(tiles): S.paste(Image.open(fn), (270 * (n % cols), 480 * (n // cols)))
S.save(sheet)
hook = beats[0]['end']
for k, t in enumerate((min(0.6, hook / 2), max(0.1, hook - 0.3))):
    run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', out, '-frames:v', '1', '-q:v', '2', os.path.join(base, f'cover_{k+1}.jpg')])
print('done ->', out, '| check', sheet, '| covers: cover_1.jpg, cover_2.jpg')

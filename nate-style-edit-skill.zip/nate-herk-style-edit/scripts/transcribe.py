# Word-level transcript -> words.json ([{word,start,end}]). Free + local.
# Tries mlx_whisper (Apple Silicon), then faster_whisper, then openai-whisper.
# Usage: python3 transcribe.py take.mp4 words.json
import sys, json, subprocess, tempfile, os, shutil
src, out = sys.argv[1], sys.argv[2]
wav = os.path.join(tempfile.mkdtemp(), 'a.wav')
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', src, '-ac', '1', '-ar', '16000', wav], check=True)
words = None
def lib():
  try:
    import mlx_whisper
    r = mlx_whisper.transcribe(wav, path_or_hf_repo='mlx-community/whisper-large-v3-turbo', word_timestamps=True, language='en')
    return [w for s in r['segments'] for w in s['words']]
  except ImportError: pass
  try:
    from faster_whisper import WhisperModel
    segs, _ = WhisperModel('small', compute_type='int8').transcribe(wav, word_timestamps=True, language='en')
    return [{'word': w.word, 'start': w.start, 'end': w.end} for s in segs for w in s.words]
  except ImportError: pass
  try:
    import whisper
    r = whisper.load_model('small').transcribe(wav, word_timestamps=True, language='en')
    return [w for s in r['segments'] for w in s['words']]
  except ImportError: pass
  if shutil.which('mlx_whisper'):  # CLI installed for another Python
    od = os.path.dirname(wav)
    subprocess.run(['mlx_whisper', wav, '--model', 'mlx-community/whisper-large-v3-turbo', '--language', 'en',
                    '--word-timestamps', 'True', '--output-format', 'json', '--output-dir', od], check=True, capture_output=True)
    r = json.load(open(os.path.join(od, 'a.json'))); return [w for s in r['segments'] for w in s['words']]
  sys.exit('No Whisper found. Install one: pip install mlx-whisper (Apple Silicon Mac) or pip install faster-whisper')
words = lib()
words = [{'word': w['word'].strip(), 'start': round(w['start'], 3), 'end': round(w['end'], 3)} for w in words]
json.dump(words, open(out, 'w'), indent=0)
print(len(words), 'words ->', out)

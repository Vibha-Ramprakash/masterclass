# Synthesizes a split-screen-creator SFX kit (chime, ticks, ping, sub-drop, whoosh, flick).
# Tones measured from @nateherkai reels (Oct 2026). Numpy only, no samples copied.
# Usage: python3 sfx_synth.py <out_dir>
import sys, wave, numpy as np
OUT = sys.argv[1] if len(sys.argv) > 1 else '.'
SR = 48000; rng = np.random.default_rng(7)
def band(x, lo, hi):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); X[(f < lo) | (f > hi)] = 0; return np.fft.irfft(X, len(x))
def tone(f, d, decay=18, harm=((2, 0.12), (3, 0.04)), att=0.004):
    t = np.arange(int(SR * d)) / SR
    s = np.sin(2 * np.pi * f * t) + sum(a * np.sin(2 * np.pi * f * h * t) for h, a in harm)
    return s * np.minimum(t / att, 1) * np.exp(-decay * t)
def verb(x, rt=0.6, mix=0.22):
    n = int(SR * rt); ir = rng.standard_normal(n) * np.exp(-6 * np.arange(n) / n); ir /= np.abs(ir).sum() / 3
    y = np.convolve(x, ir); o = np.zeros(len(y)); o[:len(x)] += x; return o * (1 - mix) + y * mix
def save(name, x, peak=0.8):
    x = x / np.abs(x).max() * peak; d = (np.stack([x, x], 1) * 32767).astype('<i2')
    with wave.open(f'{OUT}/{name}', 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())
def place(parts, total):
    o = np.zeros(int(SR * total))
    for off, s in parts: i = int(off * SR); o[i:i + len(s)] += s[:len(o) - i]
    return o
save('chime.wav', verb(place([(0, tone(2637, 0.6, 9)), (0.11, tone(2088, 0.9, 7))], 1.4), 0.8, 0.25))   # new numbered section
tick = lambda: tone(3510, 0.05, 90, ((2, 0.05),), 0.001)
save('ticks.wav', verb(place([(k * 0.062, tick() * (1 - 0.08 * k)) for k in range(6)], 0.8), 0.3, 0.15), 0.6)  # highlight / typing
save('ping.wav', verb(place([(0, tone(3060, 0.5, 14))], 1.0), 0.7, 0.25), 0.7)   # logo / sticker pop
t = np.arange(int(SR * 1.6)) / SR; f = 45 + 65 * np.exp(-6 * t); ph = 2 * np.pi * np.cumsum(f) / SR
save('subdrop.wav', np.tanh(1.6 * np.sin(ph)) * np.exp(-2.2 * t) * np.minimum(t / 0.003, 1) + rng.standard_normal(len(t)) * np.exp(-t / 0.004) * 0.3, 0.95)  # hook
n = int(SR * 0.55); t = np.arange(n) / SR
env = np.where(t < 0.25, (t / 0.25) ** 2.2, np.exp(-(t - 0.25) * 14))
save('whoosh.wav', band(rng.standard_normal(n), 700, 9000) * env, 0.7)  # every cut, peak at 0.25s
n = int(SR * 0.12); t = np.arange(n) / SR
save('flick.wav', band(rng.standard_normal(n), 1800, 7000) * np.exp(-t / 0.012) * np.minimum(t / 0.0015, 1), 0.8)  # card entrance
print('ok')

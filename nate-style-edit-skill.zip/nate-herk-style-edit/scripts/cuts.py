# Jump-cut the talking head: removes pauses longer than --gap and any [start,end] ranges in --drop.
# Writes take_cut.mp4 and words_cut.json (timestamps shifted to the cut).
# Usage: python3 cuts.py take.mp4 words.json outdir [--gap 0.35] [--drop "12.1-14.8,30-31.2"]
import sys, json, subprocess, argparse
p = argparse.ArgumentParser(); p.add_argument('take'); p.add_argument('words'); p.add_argument('out')
p.add_argument('--gap', type=float, default=0.35); p.add_argument('--drop', default='')
a = p.parse_args(); PAD = 0.08
W = json.load(open(a.words))
drops = [tuple(map(float, d.split('-'))) for d in a.drop.split(',') if d]
W = [w for w in W if not any(s <= w['start'] < e for s, e in drops)]
keep = []
for w in W:
    s, e = max(0, w['start'] - PAD), w['end'] + PAD
    if keep and s - keep[-1][1] < a.gap: keep[-1][1] = max(keep[-1][1], e)
    else: keep.append([s, e])
for i in range(len(keep) - 1):  # never overlap
    keep[i][1] = min(keep[i][1], keep[i + 1][0])
sel = '+'.join(f'between(t,{s:.3f},{e:.3f})' for s, e in keep)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', a.take, '-vf', f"select='{sel}',setpts=N/FRAME_RATE/TB",
                '-af', f"aselect='{sel}',asetpts=N/SR/TB", '-c:v', 'libx264', '-preset', 'fast', '-crf', '16',
                '-pix_fmt', 'yuv420p', '-g', '30', '-c:a', 'aac', '-b:a', '256k', f'{a.out}/take_cut.mp4'], check=True)
out, t0 = [], 0.0
for s, e in keep:
    for w in W:
        if s <= w['start'] < e: out.append({'word': w['word'], 'start': round(w['start'] - s + t0, 3), 'end': round(min(w['end'], e) - s + t0, 3)})
    t0 += e - s
json.dump(out, open(f'{a.out}/words_cut.json', 'w'), indent=0)
print(f'{len(keep)} pieces, {t0:.2f}s ->', f'{a.out}/take_cut.mp4')
